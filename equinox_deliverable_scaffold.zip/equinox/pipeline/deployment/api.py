"""
Stage 6: Deployment
A minimal FastAPI service the dashboard (dashboard/dashboard_mockup.html,
rebuilt as a real React app) talks to. Runs locally for the demo — no
cloud dependency, per plan §4's "never rely on venue wifi" note.

Endpoints are intentionally the exact fields from the proposal's output
table (§5) so the dashboard needs zero translation logic.
"""
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Equinox Corridor Watch API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class Incident(BaseModel):
    incident_id: str
    incident_class: str          # stalled vehicle | illegal parking | debris | congestion | lane blockage
    location: str
    lat: float
    lon: float
    timestamp: datetime
    severity: str                 # Normal | Moderate | Severe | Critical
    accessibility_score: int      # 0-100
    recommended_action: str
    status: str                   # Open | Assigned | In Action | Cleared | Verified
    evidence_url: Optional[str] = None


# In-memory store for the demo — swap for SQLite/Postgres if this grows past a hackathon.
_INCIDENTS: List[Incident] = []


@app.get("/incidents", response_model=List[Incident])
def list_incidents():
    return _INCIDENTS


@app.post("/incidents", response_model=Incident)
def create_incident(incident: Incident):
    # TODO: this is where a real deployment would receive output from the
    # detector+severity pipeline (Stages 4-5) running on a replayed/live feed,
    # rather than being called directly.
    _INCIDENTS.append(incident)
    return incident


@app.patch("/incidents/{incident_id}/status")
def update_status(incident_id: str, status: str):
    for inc in _INCIDENTS:
        if inc.incident_id == incident_id:
            inc.status = status
            # TODO: when status -> "Cleared", trigger a re-check pass against
            # the latest frame for this location before allowing "Verified"
            # (plan §1.6 / §11 clearance verification step).
            return inc
    return {"error": "not found"}


@app.get("/health")
def health():
    return {"status": "ok", "incidents_tracked": len(_INCIDENTS)}
